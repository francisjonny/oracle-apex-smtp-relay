<?php
declare(strict_types=1);
require __DIR__.'/../hosting/private/Relay.php';
$config=['store'=>$argv[1].'/relay.sqlite','enabled'=>true,'hourly_limit'=>10,'daily_limit'=>10];
$relay=new Relay($config);
$p=['id'=>str_repeat('f',32),'to'=>'test@example.invalid','subject'=>'Concurrente','body'=>'Simulado','expires'=>(int)$argv[2]];
$relay->submit($p,function() use ($argv): string {
    file_put_contents($argv[1].'/calls','send\n',FILE_APPEND|LOCK_EX);
    usleep(300000);
    return '<mock@example.invalid>';
});
