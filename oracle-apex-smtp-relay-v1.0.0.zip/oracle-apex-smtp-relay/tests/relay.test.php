<?php
declare(strict_types=1);
require __DIR__ . '/../hosting/private/Relay.php';
$passed = 0;
function check(bool $condition, string $label): void {
    global $passed;
    if (!$condition) throw new RuntimeException($label);
    $passed++;
    echo "OK $label\n";
}
function fails(callable $fn, int $http, string $label): void {
    try { $fn(); } catch (RelayError $e) { check($e->http === $http, $label); return; }
    throw new RuntimeException($label . ' no fallo');
}
$dir = sys_get_temp_dir() . '/apex-mail-relay-test-' . bin2hex(random_bytes(6));
$config = ['store'=>$dir.'/relay.sqlite','enabled'=>true,'hourly_limit'=>10,'daily_limit'=>20,
    'api_key_sha256'=>hash('sha256',str_repeat('x',64))];
$p = ['id'=>str_repeat('a',32),'to'=>'test@example.invalid','subject'=>'Prueba ñ','body'=>'Texto con acentos: áéíóú','expires'=>time()+600];
$json = fn(array $p): string => json_encode($p, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
try {
    fails(fn()=>Relay::authorize($config,''),401,'sin clave');
    fails(fn()=>Relay::authorize($config,str_repeat('y',64)),401,'clave incorrecta');
    Relay::authorize($config,str_repeat('x',64)); check(true,'clave valida');
    check(Relay::validate($json($p),65536)===$p,'UTF8 y payload valido');
    $reversed = array_reverse($p,true);
    check(Relay::validate($json($reversed),65536)===$p,'orden JSON indiferente');
    fails(fn()=>Relay::validate('{',65536),400,'JSON roto');
    fails(fn()=>Relay::validate($json($p+['from'=>'evil@example.invalid']),65536),400,'remitente inyectado');
    $bad=$p; $bad['subject']="Hola\r\nBcc: evil@example.invalid";
    fails(fn()=>Relay::validate($json($bad),65536),400,'inyeccion de cabecera');
    $bad=$p; $bad['to']='a@example.invalid,b@example.invalid';
    fails(fn()=>Relay::validate($json($bad),65536),400,'multiples destinatarios');
    $bad=$p; $bad['expires']=time()-1;
    fails(fn()=>Relay::validate($json($bad),65536),410,'vencimiento');
    fails(fn()=>Relay::validate($json($p),8),413,'tamano limitado');
    $relay=new Relay($config); $calls=0;
    $send=function(array $mail) use (&$calls): string { $calls++; return '<mock@example.invalid>'; };
    $result=$relay->submit($p,$send);
    check($result['state']==='SENT' && $calls===1,'aceptacion SMTP simulada');
    $relay->submit($p,$send);
    check($calls===1,'reintento sin duplicar envio');
    $changed=$p; $changed['body']='Otro cuerpo';
    fails(fn()=>$relay->submit($changed,$send),409,'mismo ID distinto contenido');
    $p2=$p; $p2['id']=str_repeat('b',32);
    $uncertain=$relay->submit($p2,function() use (&$calls) { $calls++; throw new RuntimeException('respuesta perdida'); });
    check($uncertain['state']==='UNCERTAIN','resultado SMTP dudoso');
    $relay->submit($p2,$send);
    check($calls===2,'no reenvia estado dudoso');
    fails(fn()=>$relay->status(str_repeat('c',32)),404,'estado inexistente');
    $db = new PDO('sqlite:'.$config['store']);
    $db->exec("INSERT INTO messages VALUES('cccccccccccccccccccccccccccccccc','test','PROCESSING',0,0,NULL)");
    check($relay->status(str_repeat('c',32))['state']==='UNCERTAIN','proceso interrumpido no se reenvia');
    $rows=$db->query('PRAGMA table_info(messages)')->fetchAll(PDO::FETCH_ASSOC);
    check(!in_array('body',array_column($rows,'name')) && !in_array('to',array_column($rows,'name')),'sin cuerpos ni destinatarios en SQLite');
    $disabled=new Relay(array_replace($config,['enabled'=>false]));
    fails(fn()=>$disabled->submit($p,$send),503,'envio deshabilitado');
    $limited=new Relay(array_replace($config,['hourly_limit'=>1]));
    $p3=$p; $p3['id']=str_repeat('d',32);
    fails(fn()=>$limited->submit($p3,$send),429,'limite horario');
    require __DIR__.'/../hosting/private/vendor/autoload.php';
    $mail=new PHPMailer\PHPMailer\PHPMailer(true);
    $mail->CharSet='UTF-8'; $mail->setFrom('sender@example.invalid','APEX Mail Relay');
    $mail->addAddress('test@example.invalid'); $mail->Subject='Suscripción ñ';
    $mail->Body="Correo de prueba áéíóú\n.linea"; $mail->preSend();
    $mime=$mail->getSentMIMEMessage();
    check(str_contains($mime,'charset=UTF-8') && str_contains($mime,'MIME-Version:'),'MIME de PHPMailer generado sin envio');
    echo "PASS $passed pruebas. Cero mensajes enviados.\n";
} finally {
    unset($relay,$disabled,$limited,$db);
    if(is_file($config['store'])) unlink($config['store']);
    if(is_dir($dir)) rmdir($dir);
}
