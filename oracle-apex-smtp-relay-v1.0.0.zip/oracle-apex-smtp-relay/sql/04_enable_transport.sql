-- After enabling the PHP relay personally. Does not process messages.
begin
  AMR_MAIL.health(true);
  update AMR_CONFIG set enabled='Y' where id=1;
end;
/
commit;
