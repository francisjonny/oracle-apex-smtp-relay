-- Read-only. No credentials, messages or connection strings.
select sys_context('USERENV','CURRENT_USER') current_user_name,
       sys_context('USERENV','CURRENT_SCHEMA') current_schema_name from dual;
select version_no from apex_release;
select privilege from session_privs
where privilege in ('CREATE TABLE','CREATE PROCEDURE','CREATE JOB') order by privilege;
select name,type,line,position,text from user_errors
where name='AMR_MAIL' and attribute='ERROR' order by sequence;
