-- Counts and delivery metadata only. No bodies, recipients or tokens.
select name,type,line,position,text from user_errors where name='AMR_MAIL' and attribute='ERROR' order by sequence;
select state,count(*) messages from AMR_OUTBOX group by state;
select id,request_id,state,attempts,last_error,created_at,updated_at
from AMR_OUTBOX order by id desc fetch first 20 rows only;
select job_name,enabled,state,failure_count,last_start_date,next_run_date
from user_scheduler_jobs where job_name='AMR_MAIL_WORKER';
select status,error#,actual_start_date,run_duration
from user_scheduler_job_run_details where job_name='AMR_MAIL_WORKER'
order by log_date desc fetch first 10 rows only;
