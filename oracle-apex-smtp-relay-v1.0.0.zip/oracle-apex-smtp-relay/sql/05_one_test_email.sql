-- Sends ONE real email. Replace address with a mailbox you own.
-- Run once, inspect state and inbox; do not repeat on UNCERTAIN.
declare
  recipient varchar2(254):='you@example.com'; n number;
begin
  if recipient='you@example.com' then raise_application_error(-20909,'Set your own test recipient first.'); end if;
  select count(*) into n from AMR_OUTBOX where state in ('NEW','PROCESSING');
  if n>0 then raise_application_error(-20909,'Review pending messages before this test.'); end if;
  AMR_MAIL.enqueue(recipient,'APEX HTTPS SMTP test',to_clob('Prueba UTF-8: áéíóú, ñ. No contiene claves ni enlaces de acceso.'));
  commit;
  AMR_MAIL.process(1);
end;
/
select id,state,attempts,last_error from AMR_OUTBOX order by id desc fetch first 1 row only;
