-- Run personally only after receiving the test email.
-- Creates a disabled job if missing; verifies its definition, then enables it.
declare
  n number; typ varchar2(30); action_text varchar2(4000); interval_text varchar2(4000);
  program_text varchar2(255); flag varchar2(5);
begin
  select count(*) into n from session_privs where privilege='CREATE JOB';
  if n=0 then raise_application_error(-20910,'Ask your DBA for CREATE JOB on your application schema.'); end if;
  select count(*) into n from AMR_OUTBOX where state='SENT';
  if n=0 then raise_application_error(-20910,'Complete the real email test first.'); end if;
  AMR_MAIL.health(true);
  select count(*) into n from user_scheduler_jobs where job_name='AMR_MAIL_WORKER';
  if n=0 then
    dbms_scheduler.create_job(job_name=>'AMR_MAIL_WORKER',job_type=>'PLSQL_BLOCK',
      job_action=>'begin AMR_MAIL.process(1); end;',start_date=>systimestamp,
      repeat_interval=>'FREQ=MINUTELY;INTERVAL=1',enabled=>false,auto_drop=>false);
  end if;
  select job_type,job_action,repeat_interval,program_name,enabled into typ,action_text,interval_text,program_text,flag
    from user_scheduler_jobs where job_name='AMR_MAIL_WORKER';
  if typ<>'PLSQL_BLOCK' or program_text is not null or
     regexp_replace(upper(action_text),'[[:space:]]','')<>'BEGINAMR_MAIL.PROCESS(1);END;' or
     nvl(upper(interval_text),'?')<>'FREQ=MINUTELY;INTERVAL=1' then
    raise_application_error(-20910,'Existing job differs; inspect it instead of replacing it.');
  end if;
  if flag<>'TRUE' then dbms_scheduler.enable('AMR_MAIL_WORKER'); end if;
end;
/
select job_name,enabled,state,failure_count from user_scheduler_jobs where job_name='AMR_MAIL_WORKER';
