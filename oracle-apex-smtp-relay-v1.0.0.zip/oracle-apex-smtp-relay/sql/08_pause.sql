-- Stops automatic processing. Existing messages and idempotency state are retained.
begin
  dbms_scheduler.disable('AMR_MAIL_WORKER');
  update AMR_CONFIG set enabled='N' where id=1;
end;
/
commit;
