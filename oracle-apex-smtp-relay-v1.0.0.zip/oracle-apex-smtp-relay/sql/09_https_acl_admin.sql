-- Run personally as database ADMIN on Autonomous, NOT workspace ADMIN.
-- Generic template: replace BOTH placeholders. No wildcard or SMTP grant.
declare
  host_name varchar2(255):='your-domain.example';
  app_schema varchar2(128):='YOUR_APEX_SCHEMA';
begin
  if sys_context('USERENV','CURRENT_USER')<>'ADMIN' then
    raise_application_error(-20911,'Use Database Actions as database ADMIN, not SQL Workshop.');
  end if;
  if host_name='your-domain.example' or app_schema='YOUR_APEX_SCHEMA' or
     not regexp_like(host_name,'^[A-Za-z0-9.-]+$') then
    raise_application_error(-20911,'Replace hostname and schema placeholders first.');
  end if;
  execute immediate q'~begin
    dbms_network_acl_admin.append_host_ace(host=>:h,lower_port=>443,upper_port=>443,
      ace=>xs$ace_type(privilege_list=>xs$name_list('http'),principal_name=>:s,principal_type=>xs_acl.ptype_db));
  end;~' using host_name,upper(app_schema);
  execute immediate q'~begin
    dbms_network_acl_admin.append_host_ace(host=>:h,lower_port=>443,upper_port=>443,
      ace=>xs$ace_type(privilege_list=>xs$name_list('http'),principal_name=>apex_application.g_flow_schema_owner,principal_type=>xs_acl.ptype_db));
  end;~' using host_name;
  commit;
end;
/
