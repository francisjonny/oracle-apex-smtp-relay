-- Authenticated HTTPS GET. Does not send email.
begin AMR_MAIL.health; end;
/
