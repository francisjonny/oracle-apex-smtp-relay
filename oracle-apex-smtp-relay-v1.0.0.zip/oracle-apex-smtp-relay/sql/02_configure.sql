-- Edit these NON-SECRET settings locally. Do not put API/SMTP keys in SQL.
declare
  l_relay_url varchar2(2000):='https://your-domain.example/apex-mail-relay/index.php';
  l_workspace varchar2(255):='YOUR_WORKSPACE';
begin
  if instr(l_relay_url,'your-domain.example')>0 or l_workspace='YOUR_WORKSPACE' then
    raise_application_error(-20908,'Replace endpoint and workspace placeholders first.');
  end if;
  merge into AMR_CONFIG c using (select 1 id from dual) x on (c.id=x.id)
  when matched then update set endpoint=l_relay_url,c.workspace_name=l_workspace,
    credential_static_id='APEX_MAIL_RELAY',enabled='N'
  when not matched then insert(id,endpoint,workspace_name,credential_static_id,enabled)
    values(1,l_relay_url,l_workspace,'APEX_MAIL_RELAY','N');
end;
/
commit;
