# Contribuir

1. Crea una rama y describe el problema con un ejemplo reproducible anonimizado.
2. Instala PHPMailer con Composer según README y ejecuta `node tools/test.cjs`.
3. Añade pruebas de comportamiento para cambios en autenticación, idempotencia,
   límites o estados. Las pruebas no deben enviar mensajes reales.
4. Ejecuta `node tools/check-publication.cjs`. No agregues configuraciones reales.
5. Abre un PR describiendo cambio, validación y limitaciones.

Los SQL son ejemplos genéricos de instalación personal. No conectes un esquema
real a CI ni subas exports, wallets, datos de negocio o tokens de activación.
Documenta cambios de contrato JSON y migraciones antes de cambiar estados.

La licencia del código propio es MIT. PHPMailer conserva su licencia LGPL-2.1;
se obtiene por Composer y no se copia en el historial del proyecto.
