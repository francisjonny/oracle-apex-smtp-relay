const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),os=require('node:os'),assert=require('node:assert/strict'),net=require('node:net'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..');
const php=process.env.AMR_TEST_PHP||'php';
const args=process.env.AMR_TEST_PHP_EXTENSION_DIR?['-n','-d','extension_dir='+process.env.AMR_TEST_PHP_EXTENSION_DIR,'-d','extension=pdo_sqlite']:[];
function run(a){const r=cp.spawnSync(php,[...args,...a],{encoding:'utf8',windowsHide:true});if(r.error)throw r.error;if(r.status!==0)throw Error(r.stdout+r.stderr);return r.stdout;}
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(d=>d.isDirectory()?files(path.join(dir,d.name)):[path.join(dir,d.name)]);}
const phpFiles=files(path.join(root,'hosting')).filter(f=>f.endsWith('.php'));
for(const f of phpFiles)run(['-l',f]);
process.stdout.write(run([path.join(root,'tests/relay.test.php')]));
function cleanTemp(temp,prefix){assert.equal(path.dirname(path.resolve(temp)),path.resolve(os.tmpdir()));assert(path.basename(temp).startsWith(prefix));fs.rmSync(temp,{recursive:true,force:true});}
(async()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'amr-race-'));
 try{
  const expires=String(Math.floor(Date.now()/1000)+600);
  const launch=()=>new Promise((resolve,reject)=>{const p=cp.spawn(php,[...args,path.join(root,'tests/concurrency.php'),temp,expires],{windowsHide:true});let err='';p.stderr.on('data',b=>err+=b);p.on('error',reject);p.on('close',n=>n===0?resolve():reject(Error(err)));});
  await Promise.all([launch(),launch()]);
  assert.equal(fs.readFileSync(path.join(temp,'calls'),'utf8'),'send\\n');
  console.log('PASS concurrency: two processes / one simulated send');
 }finally{cleanTemp(temp,'amr-race-');}
 const httpTemp=fs.mkdtempSync(path.join(os.tmpdir(),'amr-http-'));
 let server;
 try{
  for(const f of ['app.php','Relay.php'])fs.copyFileSync(path.join(root,'hosting/private',f),path.join(httpTemp,f));
  fs.cpSync(path.join(root,'hosting/private/vendor'),path.join(httpTemp,'vendor'),{recursive:true});
  const key=crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(path.join(httpTemp,'config.php'),`<?php return ['enabled'=>false,'api_key_sha256'=>'${crypto.createHash('sha256').update(key).digest('hex')}','store'=>__DIR__.'/state/relay.sqlite','sender'=>'sender@example.invalid','smtp_password'=>'fixture-only','max_bytes'=>65536,'hourly_limit'=>10,'daily_limit'=>20];`);
  // Fixture only. This router is not part of the deployed service.
  fs.writeFileSync(path.join(httpTemp,'router.php'),`<?php if (!str_starts_with($_SERVER['REQUEST_URI'],'/insecure')) $_SERVER['HTTPS']='on'; require __DIR__.'/app.php';`);
  const port=await new Promise(resolve=>{const listener=net.createServer();listener.listen(0,'127.0.0.1',()=>{const p=listener.address().port;listener.close(()=>resolve(p));});});
  const extra=process.env.AMR_TEST_PHP_EXTENSION_DIR?['-d','extension=openssl']:[];
  server=cp.spawn(php,[...args,...extra,'-S',`127.0.0.1:${port}`,path.join(httpTemp,'router.php')],{windowsHide:true,stdio:['ignore','ignore','pipe']});
  await new Promise((resolve,reject)=>{let s='';const timer=setTimeout(()=>reject(Error('PHP server did not start')),5000);server.stderr.on('data',b=>{s+=b;if(s.includes('Development Server')){clearTimeout(timer);resolve();}});server.on('error',reject);server.on('exit',n=>{if(n)reject(Error('PHP server exited'));});});
  const base=`http://127.0.0.1:${port}`,headers={'X-APEX-Mail-Key':key,'Content-Type':'application/json'};
  let response=await fetch(base+'/?action=health');assert.equal(response.status,401);
  assert(!fs.existsSync(path.join(httpTemp,'state')),'unauthenticated request created storage');
  response=await fetch(base+'/?action=health',{headers});assert.equal(response.status,200);assert.deepEqual(await response.json(),{status:'ready',enabled:false});
  response=await fetch(base+'/insecure?action=health',{headers});assert.equal(response.status,400);
  response=await fetch(base+'/?action=status&id='+'a'.repeat(32),{headers});assert.equal(response.status,404);
  response=await fetch(base+'/?action=status&id=bad',{headers});assert.equal(response.status,400);
  response=await fetch(base+'/?action=send',{headers});assert.equal(response.status,405);
  response=await fetch(base+'/?action=send',{headers:{...headers,'Content-Type':'text/plain'},method:'POST',body:'{}'});assert.equal(response.status,415);
  response=await fetch(base+'/?action=send',{headers,method:'POST',body:'x'.repeat(65537)});assert.equal(response.status,413);
  const payload={id:'e'.repeat(32),to:'test@example.invalid',subject:'Test',body:'Simulated',expires:Math.floor(Date.now()/1000)+600};
  response=await fetch(base+'/?action=send',{headers,method:'POST',body:JSON.stringify(payload)});assert.equal(response.status,503);assert.deepEqual(await response.json(),{error:'disabled'});
  console.log('PASS 10 local HTTP checks / no real messages');
 }finally{
  if(server){server.kill();await new Promise(resolve=>server.once('close',resolve));}
  cleanTemp(httpTemp,'amr-http-');
 }
 const sql=fs.readFileSync(path.join(root,'sql/01_install.sql'),'utf8');
 const start=sql.indexOf('    procedure enqueue(',sql.indexOf('create or replace package body'));
 const enqueue=sql.slice(start,sql.indexOf('    procedure health(',start));
 assert(start>0&&enqueue.length>500);assert(!enqueue.includes('make_rest_request'));assert(!/^\s*commit;/mi.test(enqueue));
 assert(sql.includes("state in ('NEW','PROCESSING')"));
 fs.writeFileSync(path.join(root,'test-results.json'),JSON.stringify({phpSyntaxFiles:phpFiles.length,unitCases:22,httpCases:10,concurrency:'two processes / one simulated send',oracleValidation:'static only; not compiled in Oracle',realEmailSent:false},null,2)+'\n');
 console.log('PASS local SQL transaction boundary checks; no Oracle connection');
})().catch(e=>{console.error(e);process.exitCode=1;});
