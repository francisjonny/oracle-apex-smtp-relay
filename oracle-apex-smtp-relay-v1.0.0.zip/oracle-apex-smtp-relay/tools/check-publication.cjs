// Defensive checks for the PUBLIC project; never follows symlinks or includes runtime files.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{
 if(e.isSymbolicLink())throw Error('Symlink is not publishable: '+e.name);
 if(e.isDirectory())return ['vendor','state','.git'].includes(e.name)?[]:walk(path.join(dir,e.name));
 return [path.join(dir,e.name)];
});}
const list=walk(root).filter(f=>path.basename(f)!=='test-results.json');
for(const file of list){
 const rel=path.relative(root,file).replaceAll('\\','/');
 assert(!/(^|\/)(config\.php|\.env(?:\..*)?|error_log)$|\.(?:sqlite\w*|log|pem|key|p12|pfx|zip|jpg|png)$/i.test(rel),'Runtime/private file: '+rel);
 const s=fs.readFileSync(file,'utf8');
 assert(!/https:\/\/[a-z0-9-]+\.adb\.[^\s"']+oraclecloudapps\.com/i.test(s),'Live cloud endpoint: '+rel);
 if(rel.endsWith('config.example.php')){
  assert(/'api_key_sha256'\s*=>\s*''/.test(s));
  assert(/'smtp_password'\s*=>\s*''/.test(s));
  assert(s.includes('mail.example.com')&&s.includes('no-reply@example.com'));
 }
}
console.log('Publication checks passed: '+list.length+' source/document files; runtime directories excluded.');
module.exports=list;
