<?php
declare(strict_types=1);

final class RelayError extends RuntimeException {
    public function __construct(public int $http, string $code) { parent::__construct($code); }
}

final class Relay {
    private PDO $db;
    public function __construct(private array $config) {
        umask(0077);
        $dir = dirname($config['store']);
        if (!is_dir($dir) && !mkdir($dir, 0700, true)) throw new RuntimeException('storage');
        $this->db = new PDO('sqlite:' . $config['store'], null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $this->db->exec('PRAGMA busy_timeout=5000');
        $this->db->exec('CREATE TABLE IF NOT EXISTS messages (
            id TEXT PRIMARY KEY, digest TEXT NOT NULL, state TEXT NOT NULL,
            created INTEGER NOT NULL, updated INTEGER NOT NULL, smtp_id TEXT)');
        @chmod($config['store'], 0600);
    }

    public static function authorize(array $config, string $key): void {
        if (strlen($key) < 32 || !preg_match('/^[a-f0-9]{64}$/D', $config['api_key_sha256'] ?? '') ||
            !hash_equals($config['api_key_sha256'], hash('sha256', $key))) throw new RelayError(401, 'unauthorized');
    }

    public static function validate(string $raw, int $max): array {
        if (strlen($raw) > $max) throw new RelayError(413, 'too_large');
        try { $p = json_decode($raw, true, 16, JSON_THROW_ON_ERROR); }
        catch (JsonException) { throw new RelayError(400, 'invalid_json'); }
        if (!is_array($p)) throw new RelayError(400, 'invalid_fields');
        $keys = array_keys($p); sort($keys);
        if ($keys !== ['body', 'expires', 'id', 'subject', 'to']) throw new RelayError(400, 'invalid_fields');
        // Canonicalizar el orden para reconocer reintentos JSON equivalentes.
        $p = ['id'=>$p['id'], 'to'=>$p['to'], 'subject'=>$p['subject'], 'body'=>$p['body'], 'expires'=>$p['expires']];
        if (!is_string($p['id']) || !preg_match('/^[a-f0-9]{32}$/D', $p['id'])) throw new RelayError(400, 'invalid_id');
        if (!is_string($p['to']) || strlen($p['to']) > 254 || !filter_var($p['to'], FILTER_VALIDATE_EMAIL) || preg_match('/[\r\n]/', $p['to'])) throw new RelayError(400, 'invalid_to');
        if (!is_string($p['subject']) || $p['subject'] === '' || strlen($p['subject']) > 800 || preg_match('/[\r\n\x00]/', $p['subject'])) throw new RelayError(400, 'invalid_subject');
        if (!is_string($p['body']) || $p['body'] === '' || str_contains($p['body'], "\0")) throw new RelayError(400, 'invalid_body');
        if (!is_int($p['expires']) || $p['expires'] <= time() || $p['expires'] > time() + 1800) throw new RelayError(410, 'expired');
        return $p;
    }

    public function status(string $id): array {
        if (!preg_match('/^[a-f0-9]{32}$/D', $id)) throw new RelayError(400, 'invalid_id');
        $q = $this->db->prepare('SELECT id,state,updated FROM messages WHERE id=?');
        $q->execute([$id]);
        $row = $q->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new RelayError(404, 'not_found');
        // Un proceso muerto no debe disparar otro envio SMTP.
        if ($row['state'] === 'PROCESSING' && (int)$row['updated'] < time() - 180) $row['state'] = 'UNCERTAIN';
        unset($row['updated']);
        return $row;
    }

    public function submit(array $p, callable $send): array {
        if (!($this->config['enabled'] ?? false)) throw new RelayError(503, 'disabled');
        $digest = hash('sha256', json_encode($p, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        $this->db->exec('BEGIN IMMEDIATE');
        try {
            $q = $this->db->prepare('SELECT digest FROM messages WHERE id=?');
            $q->execute([$p['id']]);
            $old = $q->fetchColumn();
            if ($old !== false) {
                $this->db->exec('COMMIT');
                if (!hash_equals($old, $digest)) throw new RelayError(409, 'id_conflict');
                return $this->status($p['id']);
            }
            foreach ([3600 => 'hourly_limit', 86400 => 'daily_limit'] as $seconds => $limit) {
                $q = $this->db->prepare('SELECT COUNT(*) FROM messages WHERE created>=?');
                $q->execute([time() - $seconds]);
                if ((int)$q->fetchColumn() >= (int)$this->config[$limit]) throw new RelayError(429, 'rate_limit');
            }
            $q = $this->db->prepare('INSERT INTO messages(id,digest,state,created,updated) VALUES(?,?,?,?,?)');
            $q->execute([$p['id'], $digest, 'PROCESSING', time(), time()]);
            $this->db->exec('COMMIT');
        } catch (Throwable $e) {
            // BEGIN IMMEDIATE no actualiza inTransaction en todas las versiones de PDO.
            try { $this->db->exec('ROLLBACK'); } catch (Throwable) {}
            throw $e;
        }
        try {
            $smtpId = $send($p);
            $q = $this->db->prepare("UPDATE messages SET state='SENT',updated=?,smtp_id=? WHERE id=?");
            $q->execute([time(), $smtpId, $p['id']]);
        } catch (Throwable) {
            // La desconexion pudo ocurrir despues de que SMTP aceptara DATA.
            // No guardar mensajes de error SMTP que puedan contener datos privados.
            $q = $this->db->prepare("UPDATE messages SET state='UNCERTAIN',updated=? WHERE id=?");
            $q->execute([time(), $p['id']]);
        }
        return $this->status($p['id']);
    }
}
