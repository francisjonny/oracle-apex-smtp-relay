<?php
declare(strict_types=1);
// Ejecutar PERSONALMENTE desde Terminal cPanel: php ~/apex-mail-relay-private/setup.php
// Nunca publicar este archivo dentro de public_html. No imprime secretos.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if (is_file(__DIR__.'/config.php')) { fwrite(STDERR,"config.php ya existe; revisar manualmente.\n"); exit(1); }
if (PHP_OS_FAMILY !== 'Linux') { fwrite(STDERR,"Preparado para Terminal Linux del hosting.\n"); exit(1); }
function hidden(string $prompt): string {
    fwrite(STDOUT,$prompt);
    $mode=shell_exec('stty -g');
    if (!$mode) throw new RuntimeException('No se puede ocultar la entrada.');
    shell_exec('stty -echo');
    try { $value=rtrim((string)fgets(STDIN),"\r\n"); }
    finally { shell_exec('stty '.escapeshellarg(trim($mode))); fwrite(STDOUT,"\n"); }
    return $value;
}
$config=require __DIR__.'/config.example.php';
function prompt(string $label): string { fwrite(STDOUT,$label); return trim((string)fgets(STDIN)); }
$config['smtp_host']=prompt('Servidor SMTP (nombre DNS): ');
$config['sender']=prompt('Remitente autorizado (correo completo): ');
$config['smtp_user']=prompt('Usuario SMTP: ');
if (!preg_match('/^[A-Za-z0-9.-]+$/D',$config['smtp_host']) ||
    $config['smtp_host']==='mail.example.com' ||
    !filter_var($config['sender'],FILTER_VALIDATE_EMAIL) ||
    $config['sender']==='no-reply@example.com' || $config['smtp_user']==='') {
    fwrite(STDERR,"Completar datos SMTP reales, sin valores de ejemplo.\n"); exit(1);
}
$key=hidden('Clave API propia (64 caracteres aleatorios recomendados; minimo 32): ');
if (strlen($key)<32 || strlen($key)>512) { fwrite(STDERR,"Longitud de clave invalida.\n"); exit(1); }
$password=hidden('Contrasena SMTP (no se mostrara): ');
if ($password==='') { fwrite(STDERR,"Falta contrasena.\n"); exit(1); }
$config['api_key_sha256']=hash('sha256',$key);
$config['smtp_password']=$password;
umask(0077);
$handle=fopen(__DIR__.'/config.php','x');
if (!$handle) throw new RuntimeException('No se pudo crear configuracion.');
fwrite($handle,"<?php\nreturn ".var_export($config,true).";\n"); fclose($handle);
chmod(__DIR__.'/config.php',0600);
unset($key,$password,$config);
echo "Configuracion guardada fuera del sitio publico; envio DESHABILITADO.\n";
