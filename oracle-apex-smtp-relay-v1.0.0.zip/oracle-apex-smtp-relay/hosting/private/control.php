<?php
declare(strict_types=1);
// Solo CLI. No imprime claves ni contrasenas.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$path=__DIR__.'/config.php';
if (!is_file($path)) { fwrite(STDERR,"Ejecutar antes setup.php.\n"); exit(1); }
$config=require $path;
$command=$argv[1] ?? 'status';
if (!in_array($command,['status','enable','disable'],true)) {
    fwrite(STDERR,"Uso: php control.php status|enable|disable\n"); exit(2);
}
if ($command!=='status') {
    if ($command==='enable' && (!preg_match('/^[a-f0-9]{64}$/D',$config['api_key_sha256'] ?? '') ||
        ($config['smtp_password'] ?? '')==='')) { fwrite(STDERR,"Configuracion incompleta.\n"); exit(1); }
    $config['enabled']=$command==='enable';
    umask(0077); $tmp=$path.'.tmp-'.bin2hex(random_bytes(8));
    $h=fopen($tmp,'x');
    if (!$h) throw new RuntimeException('No se pudo guardar el estado.');
    try {
        $data="<?php\nreturn ".var_export($config,true).";\n";
        if (fwrite($h,$data)!==strlen($data)) throw new RuntimeException('Escritura incompleta.');
        fflush($h); fclose($h); $h=null; chmod($tmp,0600);
        if (!rename($tmp,$path)) throw new RuntimeException('No se pudo activar la configuracion.');
    } finally { if(is_resource($h)) fclose($h); if(is_file($tmp)) unlink($tmp); }
}
echo json_encode(['enabled'=>(bool)$config['enabled'],'hourly_limit'=>$config['hourly_limit'],
    'daily_limit'=>$config['daily_limit']],JSON_PRETTY_PRINT),"\n";
