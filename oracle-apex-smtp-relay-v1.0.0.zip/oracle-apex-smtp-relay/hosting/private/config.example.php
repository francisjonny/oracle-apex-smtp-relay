<?php
declare(strict_types=1);
// Copiar a config.php FUERA de public_html. Completar secretos personalmente.
return [
    'enabled' => false,
    'api_key_sha256' => '', // SHA256 hexadecimal de una clave aleatoria de 32 bytes o mas.
    'store' => __DIR__ . '/state/relay.sqlite',
    'sender' => 'no-reply@example.com',
    'sender_name' => 'APEX Mail Relay',
    'smtp_host' => 'mail.example.com',
    'smtp_port' => 587,
    'smtp_user' => 'no-reply@example.com',
    'smtp_password' => '',
    'hourly_limit' => 40,
    'daily_limit' => 100,
    'max_bytes' => 65536,
];
