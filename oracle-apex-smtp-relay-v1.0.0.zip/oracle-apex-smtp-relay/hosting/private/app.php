<?php
declare(strict_types=1);
require __DIR__ . '/Relay.php';
try {
    if (($_SERVER['HTTPS'] ?? '') !== 'on') throw new RelayError(400, 'https_required');
    $config = require __DIR__ . '/config.php';
    Relay::authorize($config, $_SERVER['HTTP_X_APEX_MAIL_KEY'] ?? '');
    $action = $_GET['action'] ?? 'send';
    $method = $_SERVER['REQUEST_METHOD'] ?? '';
    if ($action === 'health' && $method === 'GET') {
        $ready = PHP_VERSION_ID >= 80100 && extension_loaded('pdo_sqlite') && extension_loaded('openssl') && is_file(__DIR__ . '/vendor/autoload.php');
        if (!$ready) throw new RelayError(503, 'dependencies');
        new Relay($config);
        echo json_encode(['status' => 'ready', 'enabled' => (bool)$config['enabled']]);
        exit;
    }
    $relay = new Relay($config);
    if ($action === 'status' && $method === 'GET') {
        echo json_encode($relay->status($_GET['id'] ?? ''), JSON_THROW_ON_ERROR);
        exit;
    }
    if ($action !== 'send' || $method !== 'POST') throw new RelayError(405, 'method');
    if (strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0])) !== 'application/json') throw new RelayError(415, 'content_type');
    $max = (int)$config['max_bytes'];
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > $max) throw new RelayError(413, 'too_large');
    $raw = file_get_contents('php://input', false, null, 0, $max + 1);
    $p = Relay::validate($raw === false ? '' : $raw, $max);
    // Fallar ANTES de registrar PROCESSING si falta configuracion SMTP.
    if (($config['smtp_password'] ?? '') === '' || !filter_var($config['sender'], FILTER_VALIDATE_EMAIL)) throw new RelayError(503, 'smtp_not_configured');
    $result = $relay->submit($p, function(array $p) use ($config): string {
        require_once __DIR__ . '/vendor/autoload.php';
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        $mail->isSMTP();
        $mail->SMTPDebug = 0;
        $mail->Host = $config['smtp_host'];
        $mail->Port = (int)$config['smtp_port'];
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->SMTPAuth = true;
        $mail->Username = $config['smtp_user'];
        $mail->Password = $config['smtp_password'];
        $mail->Timeout = 15;
        $mail->CharSet = 'UTF-8';
        $mail->setFrom($config['sender'], $config['sender_name']);
        $mail->addAddress($p['to']);
        $mail->Subject = $p['subject'];
        $mail->Body = $p['body'];
        $mail->isHTML(false);
        $domain = substr(strrchr($config['sender'], '@'), 1);
        $mail->MessageID = '<apex-mail-relay-' . $p['id'] . '@' . $domain . '>';
        $mail->send();
        return $mail->getLastMessageID();
    });
    echo json_encode($result, JSON_THROW_ON_ERROR);
} catch (RelayError $e) {
    http_response_code($e->http);
    if ($e->http === 429) header('Retry-After: 60');
    echo json_encode(['error' => $e->getMessage()]);
} catch (Throwable) {
    http_response_code(503);
    echo '{"error":"unavailable"}';
}
