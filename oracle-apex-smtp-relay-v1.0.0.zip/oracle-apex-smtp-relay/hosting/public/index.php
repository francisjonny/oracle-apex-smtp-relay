<?php
declare(strict_types=1);
// Instalar SOLO este archivo en /home/USUARIO/public_html/apex-mail-relay/index.php.
// Todo el resto se instala en /home/USUARIO/apex-mail-relay-private/.
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (PHP_VERSION_ID < 80100) {
    http_response_code(503);
    echo '{"error":"php_version_requires_8_1"}';
    exit;
}
$private = dirname(__DIR__, 2) . '/apex-mail-relay-private';
if (!is_file($private . '/app.php') || !is_file($private . '/config.php')) {
    http_response_code(503);
    echo '{"error":"not_configured"}';
    exit;
}
require $private . '/app.php';
